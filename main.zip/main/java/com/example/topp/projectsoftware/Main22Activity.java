package com.example.topp.projectsoftware;

import android.location.Address;
import android.location.Geocoder;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.widget.Switch;
import android.telephony.SmsManager;
import android.widget.CompoundButton;
import android.os.Handler;
import android.widget.Toast;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class Main22Activity extends ActionBarActivity {
    Switch mySwitch;
    Handler h;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main22);

       // Bundle bundle = getIntent().getExtras();
        final String phone = getIntent().getStringExtra("phone");

        mySwitch = (Switch) findViewById(R.id.switch1);
        mySwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    mySwitch.setText("On");
                    final int delay = 10000; //1000milliseconds = 1Second
                    h = new Handler();
                    h.postDelayed(new Runnable() { /// postDelayed beta5od 2 parameters, Runnable and time.
                        public void run() {
                            String message = "Couldn't get location";
                            GPSTracker gps = new GPSTracker(Main22Activity.this);

                            Geocoder geocoder = new Geocoder(Main22Activity.this, Locale.getDefault());
                            List<Address> addresses;
                            try {
                                addresses = geocoder.getFromLocation(gps.getLatitude(), gps.getLongitude(), 1);
                                String address = addresses.get(0).getAddressLine(0);
                                String city = addresses.get(0).getAddressLine(1);
                                String state = addresses.get(0).getAddressLine(3);
                                String country = addresses.get(0).getCountryName();
                                String knownName = addresses.get(0).getFeatureName();

                                message = address + ", " + city + ", " + state + ", " + country + ", " + knownName;

                                String phoneNo = phone;
                                SmsManager smsManager = SmsManager.getDefault();
                                smsManager.sendTextMessage(phoneNo, null, message, null, null);
                                Toast.makeText(Main22Activity.this, "SMS sent!", Toast.LENGTH_SHORT).show();

                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            h.postDelayed(this, delay);
                        }
                    }, delay);


                } else {
                    mySwitch.setText("Off");
                    h.removeCallbacksAndMessages(null); // stops the handler

                }
            }

        });

    }

}
