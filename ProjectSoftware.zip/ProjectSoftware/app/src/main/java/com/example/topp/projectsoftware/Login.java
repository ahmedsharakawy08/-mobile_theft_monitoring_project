package com.example.topp.projectsoftware;

public class Login {
        String name;
        String password;
       String phoneNumber;




    Login ( String name, String pass,String phoneNumber )
        {
            this.name = name;
            this.password = pass;
            this.phoneNumber = phoneNumber;

        }

        public  String getPassword()
        {
            return password;
        }

        public  String getName()
        {
            return name;
        }
        public  String getPhoneNumber()
        {
            return phoneNumber;
        }



}


