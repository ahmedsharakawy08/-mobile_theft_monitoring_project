package com.example.topp.projectsoftware;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;
import java.util.List;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {

    // All Static variables
    // Database Version
    private static final int DATABASE_VERSION = 1;

    // Database Name
    private static final String DATABASE_NAME = "ProjectATM";

    // Contacts table name
    private static final String TABLE_SingUp = "SignUp";
    private static final String TABLE_Contact = "contact";

    // Contacts Table Columns names

    private static final String KEY_NAME = "name";
    private static final String KEY_PH_NO = "phone_number";
    private static final String KEY_pass = "password";

    public DatabaseHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Creating Tables
    // Creating Tables
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_SignUP_TABLE = "CREATE TABLE " + TABLE_SingUp +
                "("
                + KEY_NAME + " TEXT,"
                + KEY_PH_NO + " TEXT,"
                + KEY_pass + " TEXT"
                +
                ")";
        db.execSQL(CREATE_SignUP_TABLE);
    }


    // Upgrading database
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Drop older table if existed
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_SingUp);
        onCreate(db);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_Contact);
        onCreate(db);
    }

    /**
     * All CRUD(Create, Read, Update, Delete) Operations
     */
    /*public void addNumber(Login l)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, login.getName()); // Contact Name
        values.put(KEY_PH_NO, login.getPhoneNumber()); // Contact Phone
        values.put(KEY_pass, login.getPassword());

        // Inserting Row
        db.insert(TABLE_SingUp, null, values);
        db.close(); // Closing database connection
    }*/
    // Adding new contact
    void addLogin(Login login) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, login.getName()); // Contact Name
        values.put(KEY_PH_NO, login.getPhoneNumber()); // Contact Phone
        values.put(KEY_pass, login.getPassword());

        // Inserting Row
        db.insert(TABLE_SingUp, null, values);
        db.close(); // Closing database connection
    }
}
    /*void addHistory(ContactsList contacts ) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, contacts.getName()); // Contact Name
        values.put(KEY_PH_NO, contacts.getPhoneNumber()); // Contact Phone

        // Inserting Row
        db.insert(TABLE_SingUp, null, values);
        db.close(); // Closing database connection
    }

   /* public void removeContact(String name) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_CONTACTS, KEY_NAME + " = ?",
                new String[]{String.valueOf(name)});
        db.close();
    }*/
   /* public int updateContact(Contact newcontact, String oldname) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, newcontact.getName());
        values.put(KEY_PH_NO, newcontact.getPhoneNumber());

        // updating row
        return db.update(TABLE_CONTACTS, values, KEY_NAME + " = ?", new String[] { oldname });
    }

    // Getting single contact


    // Getting All Contacts
    public ArrayList<Contact> getAllContacts() {
        ArrayList<Contact> contactList = new ArrayList<Contact>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + TABLE_CONTACTS;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                Contact contact = new Contact();
                contact.setID(Integer.parseInt(cursor.getString(0)));
                contact.setName(cursor.getString(1));
                contact.setPhoneNumber(cursor.getString(2));
                // Adding contact to list
                contactList.add(contact);
            } while (cursor.moveToNext());
        }

        // return contact list
        return contactList;
    }

    // Updating single contact
    /*public int updateContact(Contact contact) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, contact.getName());
        values.put(KEY_PH_NO, contact.getPhoneNumber());

        // updating row
        return db.update(TABLE_CONTACTS, values, KEY_ID + " = ?",
                new String[] { String.valueOf(contact.getID()) });
    }*/

    // Deleting single contact



    // Getting contacts Count


    // ArrayList<Contact> contactList = new ArrayList<Contact>();




    // return contact list
   /* public ContactsList[] getAllContacts() {

        String selectQuery = "SELECT  * FROM " + TABLE_SingUp;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        ContactsList arr[]=new  ContactsList[cursor.getCount()];

        if (cursor.moveToFirst()) {
            int i=0;
            do {
                arr[i].setName(cursor.getString(0));
                arr[i].setPhoneNumber(cursor.getString(1));
                i++;
            } while (cursor.moveToNext());
        }

        return arr;
    }

}*/

