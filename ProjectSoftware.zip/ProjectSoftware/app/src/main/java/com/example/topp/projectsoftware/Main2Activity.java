package com.example.topp.projectsoftware;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;

public class Main2Activity extends AppCompatActivity {

    EditText x;
    EditText y;
    EditText z;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        x = (EditText) findViewById(R.id.editText);
        z = (EditText) findViewById(R.id.editText2);
        y = (EditText) findViewById(R.id.editText2);


    }
    public void fun(View v)
    {
        String name = x.getText().toString();
        String pass = y.getText().toString();
        String phoneNumber = z.getText().toString();


        DatabaseHandler db=new DatabaseHandler(this);
        Login login=new Login(name,  pass,phoneNumber);
        db.addLogin(login);

        Intent xx=new Intent(this, MainActivity.class);
        startActivity(xx);
    }

}
