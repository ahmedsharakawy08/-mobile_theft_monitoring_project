package com.example.topp.projectsoftware;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Main22Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main22);
    }
    public void  done(View v)
    {
        Intent x = new Intent(this,MainActivity.class);
        startActivity(x);
    }
    public void signup (View v)
    {
        Intent x = new Intent(this,Main2Activity.class);
        startActivity(x);

    }
}
